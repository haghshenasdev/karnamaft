import 'dart:typed_data';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:karnamaft/api/api_client.dart';
import 'package:karnamaft/api/api_error_handler.dart';
import 'package:karnamaft/models/page_result.dart';
import 'package:karnamaft/models/record_filter.dart';
import 'package:karnamaft/models/record_item.dart';
import 'package:karnamaft/models/task_model.dart';
import 'package:karnamaft/services/RecordService.dart';
import 'package:karnamaft/storage/auth_storage.dart';
import 'package:karnamaft/widgets/date_record_filter.dart';
import 'package:karnamaft/widgets/reference_record_filter.dart';

class TaskService implements RecordService<TaskModel> {
  const TaskService();

  final String rootPath = "/mobile/v1/tasks";

  @override
  Future<PageResult<RecordItem>> list({
    int page = 1,
    String? search,
    String? sort,
    Map<String, String>? filters,
  }) async {
    try {
      final query = <String, dynamic>{"page": page};

      if (sort != null) {
        query["sort"] = sort;
      }

      if (search != null && search.isNotEmpty) {
        query["search"] = search;
      }

      if (filters != null) {
        filters.forEach((key, value) {
          if (value.isNotEmpty) {
            query["filter[$key]"] = value;
          }
        });
      }

      final response = await ApiClient.dio.get(
        rootPath,
        queryParameters: query,
      );

      final json = response.data;

      final List<dynamic> items = json["data"] ?? [];

      final records = items
          .map((e) => TaskModel.fromJson(e).toRecord())
          .toList();

      return PageResult<RecordItem>(
        data: records,

        currentPage: json["meta"]["current_page"] ?? 1,

        lastPage: json["meta"]["last_page"] ?? 1,

        total: json["meta"]["total"] ?? records.length,

        perPage: json["meta"]["per_page"] ?? records.length,
      );
    } catch (e) {
      throw ApiErrorHandler.handle(e);
    }
  }

  Future<TaskModel> show(int id) async {
    try {
      final response = await ApiClient.dio.get("$rootPath/$id");

      return TaskModel.fromJson(response.data["data"]);
    } catch (e) {
      throw ApiErrorHandler.handle(e);
    }
  }

  Future<bool> delete(int id) async {
    try {
      final response = await ApiClient.dio.delete("$rootPath/$id");

      return response.statusCode == 200;
    } catch (e) {
      throw ApiErrorHandler.handle(e);
    }
  }

  Future<Uint8List?> getFile(int id, String? fileName) async {
    if (fileName == null || fileName.trim().isEmpty) {
      return null;
    }

    final token = await AuthStorage.getToken();

    final response = await ApiClient.dio.get<List<int>>(
      "/mobile/v1/files/tasks/$id/main",

      options: Options(
        responseType: ResponseType.bytes,

        headers: {"Authorization": "Bearer $token"},
      ),
    );

    if (response.data == null) {
      return null;
    }

    return Uint8List.fromList(response.data!);
  }

  Future<TaskModel> update(
    int id,
    TaskModel model, {
    String? uploadFile,
    List<String>? uploadFiles,
  }) async {
    try {
      final formData = FormData();

      formData.fields.addAll([
        const MapEntry("_method", "PUT"),
        MapEntry("name", model.name),
        MapEntry("description", model.description ?? ""),
        MapEntry("status", model.status?.toString() ?? ""),
        MapEntry("progress", model.progress?.toString() ?? ""),
        MapEntry("completed", model.completed?.toString() ?? ""),
        MapEntry("started_at", model.startedAt ?? ""),
        MapEntry("ended_at", model.endedAt ?? ""),
        MapEntry("created_by", model.creator?.id.toString() ?? ""),
        MapEntry("minutes_id", model.minutesId?.toString() ?? ""),
      ]);

      final files = <String>[];

      if (uploadFile != null && uploadFile.isNotEmpty) {
        files.add(uploadFile);
      }

      if (uploadFiles != null) {
        for (final path in uploadFiles) {
          if (path.isNotEmpty && !files.contains(path)) {
            files.add(path);
          }
        }
      }

      for (final path in files) {
        formData.files.add(
          MapEntry(
            "upload_files[]",
            await MultipartFile.fromFile(
              path,
              filename: path.split(RegExp(r'[/\\]')).last,
            ),
          ),
        );
      }

      final response = await ApiClient.dio.post(
        "$rootPath/$id",
        data: formData,
        options: Options(
          contentType: "multipart/form-data",
          receiveTimeout: const Duration(minutes: 2),
          sendTimeout: const Duration(minutes: 2),
        ),
      );

      return TaskModel.fromJson(response.data["data"]);
    } catch (e) {
      if (e is DioException) {
        debugPrint(e.response?.data?.toString());
      }

      throw ApiErrorHandler.handle(e);
    }
  }


  /// فعالیت‌هایی که مسئول انجام آن‌ها کاربر فعلی است.
  ///
  /// `due` یکی از all/overdue/today/upcoming/completed/without_deadline است.
  Future<PageResult<TaskModel>> myTasks({
    int page = 1,
    String? search,
    String due = 'all',
  }) async {
    try {
      final query = <String, dynamic>{
        'page': page,
        'mine': '1',
      };

      if (search != null && search.trim().isNotEmpty) {
        query['search'] = search.trim();
      }

      if (due != 'all') {
        query['due'] = due;
      }

      final response = await ApiClient.dio.get(
        rootPath,
        queryParameters: query,
      );

      final json = response.data as Map<String, dynamic>;
      final items = (json['data'] as List? ?? [])
          .whereType<Map>()
          .map((e) => TaskModel.fromJson(Map<String, dynamic>.from(e)))
          .toList();

      final meta = json['meta'] as Map<String, dynamic>? ?? {};

      return PageResult<TaskModel>(
        data: items,
        currentPage: meta['current_page'] ?? 1,
        lastPage: meta['last_page'] ?? 1,
        total: meta['total'] ?? items.length,
        perPage: meta['per_page'] ?? items.length,
      );
    } catch (e) {
      throw ApiErrorHandler.handle(e);
    }
  }

  @override
  List<RecordFilter> get filters => [
    RecordFilter(
      key: "date", field: "created_at", title: "تاریخ ثبت", icon: Icons.calendar_today,
      builder: (context, values, refresh, field) => DateRecordFilter(values: values, field: field, onChanged: refresh),
    ),
    RecordFilter(
      key: "status", field: "status", title: "وضعیت", icon: Icons.flag_outlined,
      builder: (context, values, refresh, field) => DropdownButtonFormField<String>(
        value: values[field],
        decoration: const InputDecoration(labelText: "وضعیت"),
        items: const [
          DropdownMenuItem(value: "0", child: Text("جدید")),
          DropdownMenuItem(value: "1", child: Text("اتمام")),
          DropdownMenuItem(value: "2", child: Text("در حال پیگیری")),
          DropdownMenuItem(value: "3", child: Text("غیرقابل پیگیری")),
        ],
        onChanged: (v) { values[field] = v ?? ""; refresh(); },
      ),
    ),
    RecordFilter(
      key: "project_id", field: "project_id", title: "دستورکار", icon: Icons.work_outline,
      builder: (context, values, refresh, field) => ReferenceRecordFilter(
        resource: "projects", values: values, field: field, refresh: refresh, label: "دستورکار",
      ),
    ),
    RecordFilter(
      key: "city_id", field: "city_id", title: "شهر", icon: Icons.location_city_outlined,
      builder: (context, values, refresh, field) => ReferenceRecordFilter(
        resource: "cities", values: values, field: field, refresh: refresh, label: "شهر",
      ),
    ),
    RecordFilter(
      key: "Responsible_id", field: "Responsible_id", title: "مسئول", icon: Icons.person_outline,
      builder: (context, values, refresh, field) => ReferenceRecordFilter(
        resource: "users", values: values, field: field, refresh: refresh, label: "مسئول",
      ),
    ),
    RecordFilter(
      key: "completed", field: "completed", title: "انجام", icon: Icons.task_alt,
      builder: (context, values, refresh, field) => DropdownButtonFormField<String>(
        value: values[field],
        decoration: const InputDecoration(labelText: "وضعیت انجام"),
        items: const [
          DropdownMenuItem(value: "1", child: Text("انجام شده")),
          DropdownMenuItem(value: "0", child: Text("انجام نشده")),
        ],
        onChanged: (v) { values[field] = v ?? ""; refresh(); },
      ),
    ),
  ];
}
